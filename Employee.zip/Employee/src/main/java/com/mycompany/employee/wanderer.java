/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Lenovo
 */
public class wanderer extends Harbinger6th {      
    public float Komisi_3102;     
    public float TotalPenjualan_3102;     
    public float Totalgaji_3102; 
    String nama_3102;
     
     public wanderer(){ 
         
    } 
     
    public float TotalGaji_3102(){ 
        Totalgaji_3099 = gajiPokok_3102 + (Komisi_3102 * TotalPenjualan_3102);         
        return Totalgaji_3102; 
    } 

    public void TampilData_3102(){ 
        System.out.println("Komisi Karyawan"); 
        Tampil_3102(); 
        System.out.println("Total Gaji: " + Totalgaji_3102); 
    } 
} 
