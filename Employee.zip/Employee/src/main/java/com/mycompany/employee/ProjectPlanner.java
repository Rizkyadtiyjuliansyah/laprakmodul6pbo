/* 
*	Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license 
*	Click 
nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${pack agePath}/${mainClassName}.java to edit this template 
 */ 
 
package com.mycompany.employee; 
 
import java.io.BufferedReader; import java.io.InputStreamReader; 
 
/** 
 * 
*	@author lenovo 
 */ 
public class ProjectPlanner { 
 
    public static void main(String[] args) {        
        scaramouche IKY_3102 = new scaramouche();         
        wanderer Rizky_3102 = new wanderer();         
        shogunPuppet Rizkyy_3102 = new shogunPuppet(); 
         
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));  
      
        try{ 
            System.out.println("Data Pegawai");             
            System.out.print("Nama              : ");             
            IKY_3102.nama_3102 = br.readLine(); 
            System.out.print("NIP               : ");             
            IKY_3102.nip_3102 = br.readLine();             
            System.out.print("Gaji Pokok        : "); 
            IKY_3102.gajiPokok_3102 = Float.valueOf(br.readLine());             
            System.out.println("");             
           IKY_3102.TampilData_3102(); 
            System.out.println(""); 
            System.out.println(""); 
             
            System.out.print("Nama              : ");             
            Rizky_3102.nama_3102 = br.readLine();             
            System.out.print("NIP               : ");             
            Rizky_3102.nip_3102 = br.readLine();             
            System.out.print("GajiPokok         : "); 
            Rizky_3102.gajiPokok_3102 = Float.parseFloat(br.readLine());             
            System.out.print("Komisi            : "); 
            Rizky_3102.Komisi_3102 = Float.parseFloat(br.readLine());             
            System.out.print("Total Penjualan   : "); 
            Rizky_3102.TotalPenjualan_3102 = Float.parseFloat(br.readLine());             
            Rizky_3102.TotalGaji_3102();             
            System.out.println("");             
            zana_3099.TampilData_3099(); 
            System.out.println("");             
            System.out.println(""); 
             
            System.out.print("Nama              : ");             
            Rizkyy_3102.nama_3102 = br.readLine();             
            System.out.print("NIP               : ");             
            Rizkyy_3102.nip_3102 = br.readLine(); 
            System.out.print("Gaji Pokok        : "); 
            Rizkyy_3102.gajiPokok_3102 = Float.parseFloat(br.readLine());             
            System.out.print("Komisi            : "); 
            Rizkyy_3102 .Komisi_3102 = Float.parseFloat(br.readLine());             
            System.out.print("Total Hasil Proyek: "); 
            Rizkyy_3102.TotalHslProyek_3102 = Float.parseFloat(br.readLine());             
            Rizkyy_3102.TotalGaji_3102();             
            System.out.println("");             
           Rizkyy_3102.TampilData_3102();            
        } 
         
        catch(Exception ex){ 
            System.out.println(ex); 
        } 
    } 
} 
