/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Lenovo
 */
public class Harbinger6th {     
    protected String nama_3102;     
    protected String nip_3102;     
    protected float gajiPokok_3102; 
    public void Tampil_3102(){ 
        System.out.println("Nama: " + nama_3102); 
        System.out.println("NIP: " + nip_3102); 
        System.out.println("Gaji Pokok: " + gajiPokok_3102); 
    } 
} 